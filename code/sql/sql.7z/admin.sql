INSERT INTO public.admin (id, name, password) VALUES (1, 'admin', 'password');

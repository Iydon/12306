INSERT INTO public."user" (id, name, phone_number, id_card_number, password) VALUES (1, 'user_1', '1891111111 ', '130631190002140071', 'passwd');
